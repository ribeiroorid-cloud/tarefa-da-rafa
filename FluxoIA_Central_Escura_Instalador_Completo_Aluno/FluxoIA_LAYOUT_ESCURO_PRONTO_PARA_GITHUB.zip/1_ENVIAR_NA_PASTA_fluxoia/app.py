"""FluxoIA: painel demonstrativo totalmente offline após a etapa preparar.py."""
from __future__ import annotations
import json
from datetime import datetime
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from modelo_utils import preparar_calendario

BASE=Path(__file__).resolve().parent
ARTEFATOS=BASE/'artefatos'

st.set_page_config(page_title='FluxoIA | Central de Controle',page_icon='🚘',layout='wide')
# Somente estilo: não altera modelos, dados, parâmetros, previsões ou YOLO.
CSS = BASE / 'estilo_central.css'
if CSS.exists():
    st.markdown('<style>' + CSS.read_text(encoding='utf-8') + '</style>', unsafe_allow_html=True)

@st.cache_resource(show_spinner=False)
def carregar_modelo():
    return joblib.load(ARTEFATOS/'modelo_fluxo.joblib')

@st.cache_data(show_spinner=False)
def carregar_dados():
    resumo=json.loads((ARTEFATOS/'metricas.json').read_text(encoding='utf-8'))
    teste=pd.read_csv(ARTEFATOS/'demonstracao_teste.csv',parse_dates=['date_time'])
    return resumo,teste


def pt(valor,casas=0):
    return f'{valor:,.{casas}f}'.replace(',','_').replace('.',',').replace('_','.')


def prever_data(modelo,datas):
    entrada=preparar_calendario(pd.Series(pd.to_datetime(datas)))
    return np.maximum(0,modelo['modelo'].predict(entrada))


def grafico_padrao(fig,height=310):
    # Paleta escura; preserva integralmente as séries e seus valores.
    fig.update_layout(height=height,margin=dict(l=8,r=12,t=21,b=24),
                      plot_bgcolor='#101821',paper_bgcolor='#101821',
                      font=dict(family='Inter, Segoe UI, sans-serif',color='#edf6ff',size=12),showlegend=True,
                      legend=dict(orientation='h',y=-.26,x=0,font=dict(size=11)),
                      hoverlabel=dict(bgcolor='#162635',font_color='#f8fcff',bordercolor='#8bd2fc'))
    fig.update_xaxes(showgrid=False,linecolor='#3e586d',tickfont=dict(color='#bacfdf'))
    fig.update_yaxes(gridcolor='#263744',zeroline=False,minor=dict(showgrid=False),tickfont=dict(color='#bacfdf'))
    return fig




PAGINAS = (
    '01  Previsões e validação',
    '02  Planejamento operacional',
    '03  Supervisão inteligente',
)

with st.sidebar:
    c_logo, c_nome = st.columns([1, 2.5], gap='small', vertical_alignment='center')
    with c_logo:
        st.image(str(BASE / 'logo_fluxoia.png'), width=64)
    with c_nome:
        st.markdown('<div class="brand-name">Fluxo<span>IA</span></div><div class="brand-subtitle">CENTRAL DE TRÁFEGO</div>', unsafe_allow_html=True)
    st.markdown('<div class="nav-label">NAVEGAÇÃO</div>', unsafe_allow_html=True)
    pagina = st.radio('Navegação principal', PAGINAS, index=0, label_visibility='collapsed', key='nav_fluxoia')


faltando=[p for p in ['modelo_fluxo.joblib','metricas.json','demonstracao_teste.csv'] if not (ARTEFATOS/p).exists()]
if faltando:
    st.warning('O modelo ainda não foi treinado neste computador. Nenhum resultado foi inventado.')
    st.code('python preparar.py\nstreamlit run app.py',language='bash')
    st.info('A preparação obtém a base pública da UCI uma vez, treina e compara os modelos, salva as métricas e os exemplos. Depois o painel funciona offline.')
    st.stop()

try:
    pacote=carregar_modelo(); meta,dados=carregar_dados()
except Exception as e:
    st.error(f'Erro ao abrir os arquivos treinados: {e}')
    st.stop()

selecionado=meta['selecionado']
met=meta['resultados'][selecionado]['teste']
base=meta['resultados']['Baseline por dia/hora']['teste']


if pagina == PAGINAS[0]:
    st.markdown('<h1 class="page-title">Previsões <span>e validação</span></h1>', unsafe_allow_html=True)
    c1,c2,c3,c4=st.columns(4)
    c1.metric('Modelo selecionado',selecionado)
    c2.metric('MAE no teste',f"{pt(met['mae'])} veículos")
    c3.metric('Baseline MAE',f"{pt(base['mae'])} veículos")
    c4.metric('Registros históricos',pt(meta['origem_linhas']))


    # PREVISÃO LIVRE: usa somente atributos conhecidos do calendário, sem API e sem novo treino.
    st.subheader('Previsão de volume')

    hoje = datetime.now()
    cl1, cl2 = st.columns([1, 1], gap='medium')
    with cl1:
        data_livre = st.date_input('Data da previsão', value=hoje.date(), key='data_livre', format='DD/MM/YYYY')
    with cl2:
        hora_livre = st.selectbox('Hora da previsão', options=list(range(24)), index=hoje.hour,
                                 format_func=lambda h: f'{h:02d}:00', key='hora_livre')

    # Calcula o ponto escolhido e uma curva de 24 h com as mesmas variáveis do treinamento.
    instante = pd.Timestamp(data_livre) + pd.Timedelta(hours=int(hora_livre))
    horas_livres = pd.date_range(pd.Timestamp(data_livre), periods=24, freq='h')
    previsoes_livres = prever_data(pacote, horas_livres)
    prev_livre = float(previsoes_livres[int(hora_livre)])
    # Baseline não depende de rede: médias históricas salvas durante a etapa preparar.py.
    grupo_base = pacote.get('baseline_grupo', {})
    hora_base = pacote.get('baseline_hora', {})
    geral_base = float(pacote.get('baseline_geral', 0))
    def media_simples_calendario(dia_semana, hora):
        return float(grupo_base.get((int(dia_semana), int(hora)),
                                    hora_base.get(int(hora), geral_base)))
    comparacao_livre = [media_simples_calendario(dia_l.weekday(), dia_l.hour)
                        for dia_l in horas_livres]

    m1,m2,m3 = st.columns(3)
    m1.metric('Previsão do Random Forest', f'{pt(prev_livre)} veículos/h')
    m2.metric('Média histórica de referência', f'{pt(comparacao_livre[hora_livre])} veículos/h')
    m3.metric('Data e horário escolhidos', instante.strftime('%d/%m/%Y · %Hh'))

    fig_livre = go.Figure()
    fig_livre.add_trace(go.Scatter(x=horas_livres, y=previsoes_livres, mode='lines+markers',
                                  name='Previsão do Random Forest', line=dict(color='#9bdcff', width=3)))
    fig_livre.add_trace(go.Scatter(x=horas_livres, y=comparacao_livre, mode='lines',
                                  name='Baseline histórico', line=dict(color='#e7f7ff', width=2, dash='dash')))
    fig_livre.add_vline(x=instante, line_dash='dot', line_color='#f5f9ff', line_width=2)
    fig_livre.update_yaxes(title_text='Veículos por hora')
    st.plotly_chart(grafico_padrao(fig_livre, 315), use_container_width=True)

    opcoes_operacao = range(9, 19)
    mais_tranquilo = min(opcoes_operacao, key=lambda h: float(previsoes_livres[h]))

    st.divider()
    st.subheader('Validação histórica · previsão × observado')

    dados['data']=dados['date_time'].dt.date
    datas=dados['data'].drop_duplicates().to_list()
    if not datas:st.error('Conjunto de teste vazio.');st.stop()

    esq,dir=st.columns([1,2],gap='large')
    with esq:
        dia_mem=st.session_state.get('dia_historico_persistente')
        indice=(datas.index(dia_mem) if dia_mem in datas else min(len(datas)-1,max(0,len(datas)//3)))
        data=st.selectbox('Dia observado (teste)',datas,index=indice,format_func=lambda d:pd.Timestamp(d).strftime('%d/%m/%Y'),key='dia_historico_previsao')
        st.session_state['dia_historico_persistente']=data
        desse_dia=dados[dados['data']==data].copy().sort_values('date_time')
        hora=st.selectbox('Horário',list(desse_dia['date_time'].dt.strftime('%H:%M').values),index=min(10,len(desse_dia)-1))
        registro=desse_dia.loc[desse_dia['date_time'].dt.strftime('%H:%M')==hora].iloc[0]
        st.metric('Previsão do modelo',f"{pt(registro['pred_modelo'])} veículos/h")
        st.metric('Volume real observado',f"{pt(registro['traffic_volume'])} veículos/h")
        st.caption(f"Erro absoluto neste exemplo: {pt(abs(registro['pred_modelo']-registro['traffic_volume']))} veículos/h.")
        st.write('**Para que serve?** Um gestor pode comparar períodos e avaliar quando uma intervenção teria menor exposição ao tráfego.')
    with dir:
        fig=go.Figure()
        fig.add_trace(go.Scatter(x=desse_dia['date_time'],y=desse_dia['traffic_volume'],name='Volume observado',mode='lines+markers',line=dict(color='#9ddcff',width=3)))
        fig.add_trace(go.Scatter(x=desse_dia['date_time'],y=desse_dia['pred_modelo'],name='Previsão IA',mode='lines+markers',line=dict(color='#eff9ff',width=2,dash='dash')))
        fig.update_yaxes(title_text='Veículos por hora')
        st.plotly_chart(grafico_padrao(fig,330),use_container_width=True)
    with st.expander('Sobre os dados e as limitações', expanded=False):
        st.caption('Base histórica UCI: rodovia I-94, Minnesota (EUA), 2012–2018. O modelo usa dados de calendário; não monitora o trânsito atual de Cuiabá nem confirma congestionamentos ou acidentes.')
        st.caption('O gráfico de validação compara o resultado do modelo com observações reais do conjunto de teste, fora do período de treinamento.')


if pagina == PAGINAS[1]:
    st.markdown('<h1 class="page-title">Planejamento <span>operacional</span></h1>', unsafe_allow_html=True)
    st.subheader('Simulação de manutenção')

    dados['data'] = dados['date_time'].dt.date
    datas = dados['data'].drop_duplicates().to_list()
    if not datas:
        st.error('Conjunto de teste vazio.')
        st.stop()
    dia_mem=st.session_state.get('dia_historico_persistente')
    indice=(datas.index(dia_mem) if dia_mem in datas else min(len(datas)-1,max(0,len(datas)//3)))
    dia_plano=st.selectbox('Dia histórico para simulação',datas,index=indice,format_func=lambda d: pd.Timestamp(d).strftime('%d/%m/%Y'),key='dia_historico_planejamento')
    st.session_state['dia_historico_persistente']=dia_plano
    desse_dia=dados[dados['data']==dia_plano].copy().sort_values('date_time')
    candidatos=desse_dia[desse_dia['date_time'].dt.hour.between(9,18)].copy()
    if not candidatos.empty:
        escolhido=candidatos.loc[candidatos['pred_modelo'].idxmin()]
        fixo=candidatos[candidatos['date_time'].dt.hour==16]
        if not fixo.empty:
            custo_por_carro=st.slider('Custo hipotético por veículo exposto à intervenção (R$)',0.0,1.0,0.10,step=0.05)
            baseline_obs=float(fixo.iloc[0]['traffic_volume']);sugerido_obs=float(escolhido['traffic_volume'])
            a,b,c=st.columns(3)
            a.metric('Horário com menor previsão',escolhido['date_time'].strftime('%Hh'))
            b.metric('Volume real nesse horário',f'{pt(sugerido_obs)} veículos')
            c.metric('Diferença de custo · hipotética',f'R$ {pt((baseline_obs-sugerido_obs)*custo_por_carro,2)}')
        else:
            st.info('Este dia não contém registro de 16h para comparação.')
    else:
        st.info('Não há horas entre 9h e 18h suficientes para esta demonstração.')

    st.subheader('Padrões históricos de tráfego')
    l,r=st.columns(2,gap='medium')
    eda=meta['eda']
    with l:
        fig=px.bar(pd.DataFrame(eda['media_por_hora']),x='hora',y='volume',labels={'hora':'Hora do dia','volume':'Veículos/h (média)'},color_discrete_sequence=['#8bd3ff'])
        st.plotly_chart(grafico_padrao(fig,300),use_container_width=True)
    with r:
        df=pd.DataFrame(eda['media_por_dia_semana'])
        df['dia']=df['dia'].map({0:'Seg',1:'Ter',2:'Qua',3:'Qui',4:'Sex',5:'Sáb',6:'Dom'})
        fig=px.bar(df,x='dia',y='volume',labels={'dia':'Dia da semana','volume':'Veículos/h (média)'},color_discrete_sequence=['#b9e6ff'])
        st.plotly_chart(grafico_padrao(fig,300),use_container_width=True)
    with st.expander('Como interpretar esta simulação', expanded=False):
        st.caption('Valores do conjunto histórico de teste da rodovia I-94, EUA. O custo por veículo é hipotético e não representa economia operacional real comprovada. O horário sugerido é calculado entre 9h e 18h pelas previsões do modelo.')


if pagina == PAGINAS[2]:
    st.markdown('<h1 class="page-title">Supervisão <span>inteligente</span></h1>', unsafe_allow_html=True)

    from supervisao import mostrar_supervisao
    mostrar_supervisao()
    with st.expander('Sobre os alertas de vídeo', expanded=False):
        st.caption('O YOLO analisa um MP4 enviado pelo usuário e sinaliza possíveis paradas prolongadas. A detecção não confirma acidentes nem monitora câmeras públicas em tempo real.')


